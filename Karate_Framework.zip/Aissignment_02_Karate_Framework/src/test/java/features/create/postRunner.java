package features.create;

import com.intuit.karate.junit5.Karate;

public class postRunner {

    @Karate.Test
    public Karate runTest() {
        return Karate.run("createBooking").relativeTo(getClass());
    }
}
