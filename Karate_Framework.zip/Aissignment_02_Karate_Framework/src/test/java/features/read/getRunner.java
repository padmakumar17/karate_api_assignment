package features.read;

import com.intuit.karate.junit5.Karate;

public class getRunner {

    @Karate.Test
    public Karate runTest() {
        return Karate.run("getUsers").relativeTo(getClass());
    }
}
